let estudianteSeleccionado = null;

document.addEventListener("DOMContentLoaded", function () {
    listar();

    document.getElementById("btnGuardarInsertar").addEventListener("click", insertarEstudiante);
    document.getElementById("btnEliminar").addEventListener("click", abrirModalEliminar);
    document.getElementById("btnAbrirModalActualizar").addEventListener("click", abrirModalActualizar);
    document.getElementById("btnConfirmarEliminar").addEventListener("click", eliminarEstudiante);
});

function listar() {
    fetch("../../controllers/api.php?accion=listar")
        .then(response => response.json())
        .then(data => {
            let contenido = "";

            data.forEach(estudiante => {
                contenido += `
                    <tr 
                        data-cedula="${estudiante.cedula}"
                        data-nombre="${estudiante.nombre}"
                        data-apellido="${estudiante.apellido}"
                        data-telefono="${estudiante.telefono}"
                        data-direccion="${estudiante.direccion}"
                    >
                        <td>${estudiante.cedula}</td>
                        <td>${estudiante.nombre}</td>
                        <td>${estudiante.apellido}</td>
                        <td>${estudiante.telefono}</td>
                        <td>${estudiante.direccion}</td>
                    </tr>
                `;
            });

            document.getElementById("contenidoTabla").innerHTML = contenido;

            activarSeleccionFilas();
        })
        .catch(error => {
            console.error("Error al listar:", error);
        });
}

function activarSeleccionFilas() {
    const filas = document.querySelectorAll("#contenidoTabla tr");

    filas.forEach(fila => {
        fila.addEventListener("click", function () {
            filas.forEach(f => f.classList.remove("fila-seleccionada"));

            this.classList.add("fila-seleccionada");

            estudianteSeleccionado = {
                cedula: this.dataset.cedula,
                nombre: this.dataset.nombre,
                apellido: this.dataset.apellido,
                telefono: this.dataset.telefono,
                direccion: this.dataset.direccion
            };

            console.log("Estudiante seleccionado:", estudianteSeleccionado);
        });
    });
}

function insertarEstudiante() {
    const cedula = document.getElementById("cedulaInsertar").value;
    const nombre = document.getElementById("nombreInsertar").value;
    const apellido = document.getElementById("apellidoInsertar").value;
    const telefono = document.getElementById("telefonoInsertar").value;
    const direccion = document.getElementById("direccionInsertar").value;

    const formData = new FormData();
    formData.append("cedula", cedula);
    formData.append("nombre", nombre);
    formData.append("apellido", apellido);
    formData.append("telefono", telefono);
    formData.append("direccion", direccion);

    fetch("../../controllers/api.php?accion=insertar", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Estudiante insertado correctamente");
                document.getElementById("formInsertar").reset();

                const modal = bootstrap.Modal.getInstance(document.getElementById("modalInsertar"));
                modal.hide();

                estudianteSeleccionado = null;
                listar();
            } else {
                alert("No se pudo insertar el estudiante");
            }
        })
        .catch(error => {
            console.error("Error al insertar:", error);
        });
}

function abrirModalEliminar() {
    if (!estudianteSeleccionado) {
        alert("Seleccione un estudiante para eliminar");
        return;
    }

    const modalEliminar = new bootstrap.Modal(document.getElementById("modalEliminar"));
    modalEliminar.show();
}

function abrirModalActualizar() {
    if (!estudianteSeleccionado) {
        alert("Seleccione un estudiante para actualizar");
        return;
    }

    document.getElementById("cedulaActualizar").value = estudianteSeleccionado.cedula;
    document.getElementById("nombreActualizar").value = estudianteSeleccionado.nombre;
    document.getElementById("apellidoActualizar").value = estudianteSeleccionado.apellido;
    document.getElementById("telefonoActualizar").value = estudianteSeleccionado.telefono;
    document.getElementById("direccionActualizar").value = estudianteSeleccionado.direccion;
    document.getElementById("btnGuardarActualizar").addEventListener("click", actualizarEstudiante);

    const modalActualizar = new bootstrap.Modal(document.getElementById("modalActualizar"));
    modalActualizar.show();
}

function eliminarEstudiante() {
    if (!estudianteSeleccionado) {
        alert("No hay estudiante seleccionado");
        return;
    }

    const formData = new FormData();
    formData.append("cedula", estudianteSeleccionado.cedula);

    fetch("../../controllers/api.php?accion=eliminar", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Estudiante eliminado correctamente");

                const modal = bootstrap.Modal.getInstance(document.getElementById("modalEliminar"));
                modal.hide();

                estudianteSeleccionado = null;

                listar();
            } else {
                alert("No se pudo eliminar");
            }
        })
        .catch(error => {
            console.error("Error al eliminar:", error);
        });
}


function actualizarEstudiante() {
    const cedula = document.getElementById("cedulaActualizar").value;
    const nombre = document.getElementById("nombreActualizar").value;
    const apellido = document.getElementById("apellidoActualizar").value;
    const telefono = document.getElementById("telefonoActualizar").value;
    const direccion = document.getElementById("direccionActualizar").value;

    const formData = new FormData();
    formData.append("cedula", cedula);
    formData.append("nombre", nombre);
    formData.append("apellido", apellido);
    formData.append("telefono", telefono);
    formData.append("direccion", direccion);

    fetch("../../controllers/api.php?accion=actualizar", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Estudiante actualizado correctamente");

                const modal = bootstrap.Modal.getInstance(document.getElementById("modalActualizar"));
                modal.hide();

                estudianteSeleccionado = null;

                listar();
            } else {
                alert("No se pudo actualizar");
            }
        })
        .catch(error => {
            console.error("Error al actualizar:", error);
        });
}