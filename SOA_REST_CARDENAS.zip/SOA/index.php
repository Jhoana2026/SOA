<?php
header("Location: views/estudiantes/index.php");
exit();