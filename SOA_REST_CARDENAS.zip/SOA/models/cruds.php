<?php
require_once("conexion.php");

class Crud
{
    public static function listar()
    {
        $objconexion = new Conexion();
        $conectar = $objconexion->Conectar();

        $sql = "SELECT * FROM estudiantes";
        $resultado = $conectar->prepare($sql);
        $resultado->execute();

        return $resultado->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function insertar($cedula, $nombre, $apellido, $telefono, $direccion)
    {
        $objconexion = new Conexion();
        $conectar = $objconexion->Conectar();

        $sql = "INSERT INTO estudiantes (cedula, nombre, apellido, telefono, direccion)
                VALUES (:cedula, :nombre, :apellido, :telefono, :direccion)";

        $resultado = $conectar->prepare($sql);

        return $resultado->execute([
            ':cedula' => $cedula,
            ':nombre' => $nombre,
            ':apellido' => $apellido,
            ':telefono' => $telefono,
            ':direccion' => $direccion
        ]);
    }

    public static function eliminar($cedula)
    {
      $objconexion = new Conexion();
      $conectar = $objconexion->Conectar();

      $sql = "DELETE FROM estudiantes WHERE cedula = :cedula";
      $resultado = $conectar->prepare($sql);

      return $resultado->execute([
          ':cedula' => $cedula
      ]);
    }


    public static function actualizar($cedula, $nombre, $apellido, $telefono, $direccion)
    {
        $objconexion = new Conexion();
        $conectar = $objconexion->Conectar();

        $sql = "UPDATE estudiantes 
                SET nombre = :nombre, 
                    apellido = :apellido, 
                    telefono = :telefono, 
                    direccion = :direccion
                WHERE cedula = :cedula";

        $resultado = $conectar->prepare($sql);

        return $resultado->execute([
            ':cedula' => $cedula,
            ':nombre' => $nombre,
            ':apellido' => $apellido,
            ':telefono' => $telefono,
            ':direccion' => $direccion
        ]);
    }
}