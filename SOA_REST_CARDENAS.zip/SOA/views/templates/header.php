<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión de Estudiantes</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #d9d9d9;
        }

        .table-dark {
            background-color: #1e3a5f !important;
        }

        .table-dark th {
            background-color: #1e3a5f !important;
            color: white;
        }

        .fila-seleccionada {
            background-color: #dbeafe !important;
        }

        tbody tr {
            cursor: pointer;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .btn-vinotinto {
            background-color: #722f37;
            border: none;
            color: white;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-vinotinto:hover {
            background-color: #5a2530;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(114, 47, 55, 0.4);
        }

        .btn-vinotinto:active {
            transform: translateY(0);
            box-shadow: 0 2px 6px rgba(114, 47, 55, 0.4);
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h1 class="mb-4">Sistema de Gestión de Estudiantes</h1>