<?php require_once("../templates/header.php"); ?>

<div class="mb-3">
    <button type="button" class="btn btn-vinotinto" data-bs-toggle="modal" data-bs-target="#modalInsertar">
        Insertar
    </button>

    <button type="button" class="btn btn-vinotinto" id="btnAbrirModalActualizar">
        Actualizar
    </button>

    <button type="button" class="btn btn-vinotinto" id="btnEliminar">
        Eliminar
    </button>
</div>

<table class="table table-bordered table-hover" id="tablaEstudiantes">
    <thead class="table-dark">
        <tr>
            <th>Cedula</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Telefono</th>
            <th>Direccion</th>
        </tr>
    </thead>
    <tbody id="contenidoTabla">
    </tbody>
</table>

<!-- Modal Insertar -->
<div class="modal fade" id="modalInsertar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Insertar estudiante</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formInsertar">
                    <div class="mb-3">
                        <label class="form-label">Cedula</label>
                        <input type="text" class="form-control" id="cedulaInsertar" name="cedula">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="nombreInsertar" name="nombre">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Apellido</label>
                        <input type="text" class="form-control" id="apellidoInsertar" name="apellido">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefono</label>
                        <input type="text" class="form-control" id="telefonoInsertar" name="telefono">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Direccion</label>
                        <input type="text" class="form-control" id="direccionInsertar" name="direccion">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-vinotinto" id="btnGuardarInsertar">Guardar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Actualizar -->
<div class="modal fade" id="modalActualizar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Actualizar estudiante</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formActualizar">
                    <div class="mb-3">
                        <label class="form-label">Cedula</label>
                        <input type="text" class="form-control" id="cedulaActualizar" name="cedula" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="nombreActualizar" name="nombre">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Apellido</label>
                        <input type="text" class="form-control" id="apellidoActualizar" name="apellido">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefono</label>
                        <input type="text" class="form-control" id="telefonoActualizar" name="telefono">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Direccion</label>
                        <input type="text" class="form-control" id="direccionActualizar" name="direccion">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-vinotinto" id="btnGuardarActualizar">Actualizar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Eliminar -->
<div class="modal fade" id="modalEliminar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ¿Está seguro de eliminar este estudiante?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-vinotinto" id="btnConfirmarEliminar">Eliminar</button>
            </div>
        </div>
    </div>
</div>

<?php require_once("../templates/footer.php"); ?>