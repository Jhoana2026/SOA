<?php
require_once("../models/cruds.php");

if (isset($_GET["accion"])) {

    switch ($_GET["accion"]) {

        case "listar":
            $data = Crud::listar();
            echo json_encode($data);
            break;

        case "insertar":
            $cedula = $_POST["cedula"] ?? "";
            $nombre = $_POST["nombre"] ?? "";
            $apellido = $_POST["apellido"] ?? "";
            $telefono = $_POST["telefono"] ?? "";
            $direccion = $_POST["direccion"] ?? "";

            $respuesta = Crud::insertar($cedula, $nombre, $apellido, $telefono, $direccion);
            echo json_encode(["success" => $respuesta]);
            break;

        case "eliminar":
            $cedula = $_POST["cedula"] ?? "";

            $respuesta = Crud::eliminar($cedula);
            echo json_encode(["success" => $respuesta]);
            break;

        case "actualizar":
            $cedula = $_POST["cedula"] ?? "";
            $nombre = $_POST["nombre"] ?? "";
            $apellido = $_POST["apellido"] ?? "";
            $telefono = $_POST["telefono"] ?? "";
            $direccion = $_POST["direccion"] ?? "";

            $respuesta = Crud::actualizar($cedula, $nombre, $apellido, $telefono, $direccion);
            echo json_encode(["success" => $respuesta]);
            break;
    }
}